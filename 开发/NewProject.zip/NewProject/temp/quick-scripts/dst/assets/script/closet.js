
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/closet.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '76dd1yUGTpPG6ZqkIbq+xsT', 'closet');
// script/closet.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
window.lockOfClosetInCP1 = false;
var res1 = 0;
var res2 = 0;
var res3 = 0;
var res4 = 0;
var res = "";
cc.Class({
  "extends": cc.Component,
  properties: {
    sprite_Frame1: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame2: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame3: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame4: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame5: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame6: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame7: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame8: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame9: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame0: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_FrameOpen: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  // LIFE-CYCLE CALLBACKS:
  closet1: function closet1() {
    var button1 = this.node.getComponent(cc.Button);

    switch (res1) {
      case 0:
        button1.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button1.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button1.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button1.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button1.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button1.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button1.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button1.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button1.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button1.normalSprite = this.sprite_Frame0;
        break;
    }

    res1++;

    if (res1 === 10) {
      res1 = 0;
    }
  },
  closet2: function closet2() {
    var button2 = this.node.getComponent(cc.Button);

    switch (res2) {
      case 0:
        button2.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button2.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button2.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button2.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button2.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button2.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button2.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button2.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button2.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button2.normalSprite = this.sprite_Frame0;
        break;
    }

    res2++;

    if (res2 === 10) {
      res2 = 0;
    }
  },
  closet3: function closet3() {
    var button3 = this.node.getComponent(cc.Button);

    switch (res3) {
      case 0:
        button3.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button3.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button3.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button3.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button3.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button3.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button3.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button3.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button3.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button3.normalSprite = this.sprite_Frame0;
        break;
    }

    res3++;

    if (res3 === 10) {
      res3 = 0;
    }
  },
  closet4: function closet4() {
    var button4 = this.node.getComponent(cc.Button);

    switch (res4) {
      case 0:
        button4.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button4.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button4.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button4.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button4.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button4.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button4.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button4.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button4.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button4.normalSprite = this.sprite_Frame0;
        break;
    }

    res4++;

    if (res4 === 10) {
      res4 = 0;
    }
  },
  closetJudge: function closetJudge() {
    res = '' + res1 + res2 + res3 + res4;
    cc.log(res);

    if (res === "0002") {
      var closet = this.node.parent.getComponent(cc.Sprite);
      cc.log(closet);
      cc.log(this.node.sprite_FrameOpen);
      closet.spriteFrame = this.sprite_FrameOpen;
      cc.log("success");
      window.lockOfClosetInCP1 = true;
    }
  },
  // onLoad () {
  //
  // },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxjbG9zZXQuanMiXSwibmFtZXMiOlsid2luZG93IiwibG9ja09mQ2xvc2V0SW5DUDEiLCJyZXMxIiwicmVzMiIsInJlczMiLCJyZXM0IiwicmVzIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzcHJpdGVfRnJhbWUxIiwidHlwZSIsIlNwcml0ZUZyYW1lIiwic3ByaXRlX0ZyYW1lMiIsInNwcml0ZV9GcmFtZTMiLCJzcHJpdGVfRnJhbWU0Iiwic3ByaXRlX0ZyYW1lNSIsInNwcml0ZV9GcmFtZTYiLCJzcHJpdGVfRnJhbWU3Iiwic3ByaXRlX0ZyYW1lOCIsInNwcml0ZV9GcmFtZTkiLCJzcHJpdGVfRnJhbWUwIiwic3ByaXRlX0ZyYW1lT3BlbiIsImNsb3NldDEiLCJidXR0b24xIiwibm9kZSIsImdldENvbXBvbmVudCIsIkJ1dHRvbiIsIm5vcm1hbFNwcml0ZSIsImNsb3NldDIiLCJidXR0b24yIiwiY2xvc2V0MyIsImJ1dHRvbjMiLCJjbG9zZXQ0IiwiYnV0dG9uNCIsImNsb3NldEp1ZGdlIiwibG9nIiwiY2xvc2V0IiwicGFyZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQUEsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixLQUEzQjtBQUNBLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQVY7QUFBYSxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsR0FBRyxHQUFFLEVBQVQ7QUFDbERDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSQyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEMsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FEUDtJQUtSQyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEYsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FMUDtJQVNSRSxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FUUDtJQWFSRyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEosSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FiUDtJQWdCTkksYUFBYSxFQUFFO01BQ2IsV0FBVSxJQURHO01BRWJMLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZJLENBaEJUO0lBb0JSSyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWE4sSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FwQlA7SUF1Qk5NLGFBQWEsRUFBRTtNQUNiLFdBQVUsSUFERztNQUViUCxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007SUFGSSxDQXZCVDtJQTJCUk8sYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhSLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFLENBM0JQO0lBOEJOUSxhQUFhLEVBQUU7TUFDYixXQUFVLElBREc7TUFFYlQsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkksQ0E5QlQ7SUFrQ1JTLGFBQWEsRUFBRTtNQUNYLFdBQVUsSUFEQztNQUVYVixJQUFJLEVBQUVMLEVBQUUsQ0FBQ007SUFGRSxDQWxDUDtJQXNDUlUsZ0JBQWdCLEVBQUU7TUFDZCxXQUFVLElBREk7TUFFZFgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRks7RUF0Q1YsQ0FIUDtFQStDTDtFQUNBVyxPQWhESyxxQkFnREk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFFQSxRQUFRMUIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTdUIsT0FBTyxDQUFDSSxZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLZixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVFXLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLZCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFVLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVNTLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVFRLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLWCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFPLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLVixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFNLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFLLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFJLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ0RDs7SUFXQ3BCLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0FsRUk7RUFtRUw0QixPQW5FSyxxQkFtRUk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS0wsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFDQSxRQUFRekIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTNEIsT0FBTyxDQUFDRixZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNvQixPQUFPLENBQUNGLFlBQVIsR0FBdUIsS0FBS2YsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTaUIsT0FBTyxDQUFDRixZQUFSLEdBQXVCLEtBQUtkLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2dCLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNlLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLWCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNhLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLVixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNZLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNXLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNVLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ2RDs7SUFXQ25CLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0FwRkk7RUFxRkw2QixPQXJGSyxxQkFxRkk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS1AsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFDQSxRQUFReEIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTNkIsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNzQixPQUFPLENBQUNKLFlBQVIsR0FBdUIsS0FBS2YsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTbUIsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtkLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2tCLE9BQU8sQ0FBQ0osWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNpQixPQUFPLENBQUNKLFlBQVIsR0FBdUIsS0FBS1osYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTZ0IsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtYLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2UsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtWLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2MsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtULGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2EsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtSLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU1ksT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtQLGFBQTVCO1FBQTBDO0lBVnZEOztJQVdDbEIsSUFBSTs7SUFDTCxJQUFHQSxJQUFJLEtBQUcsRUFBVixFQUFhO01BQ1RBLElBQUksR0FBQyxDQUFMO0lBQ0g7RUFDSixDQXRHSTtFQXVHTDhCLE9BdkdLLHFCQXVHSTtJQUNMLElBQUlDLE9BQU8sR0FBRSxLQUFLVCxJQUFMLENBQVVDLFlBQVYsQ0FBdUJwQixFQUFFLENBQUNxQixNQUExQixDQUFiOztJQUNBLFFBQVF2QixJQUFSO01BQ0ksS0FBSyxDQUFMO1FBQVM4QixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS2xCLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU3dCLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLZixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNxQixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS2QsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTb0IsT0FBTyxDQUFDTixZQUFSLEdBQXVCLEtBQUtiLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU21CLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNrQixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS1gsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTaUIsT0FBTyxDQUFDTixZQUFSLEdBQXVCLEtBQUtWLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2dCLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNlLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ2RDs7SUFXQ2pCLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0F4SEk7RUF5SEwrQixXQXpISyx5QkF5SFE7SUFDVDlCLEdBQUcsR0FBRSxLQUFHSixJQUFILEdBQVFDLElBQVIsR0FBYUMsSUFBYixHQUFrQkMsSUFBdkI7SUFDQUUsRUFBRSxDQUFDOEIsR0FBSCxDQUFPL0IsR0FBUDs7SUFDQSxJQUFHQSxHQUFHLEtBQUcsTUFBVCxFQUFnQjtNQUNaLElBQUlnQyxNQUFNLEdBQUUsS0FBS1osSUFBTCxDQUFVYSxNQUFWLENBQWlCWixZQUFqQixDQUE4QnBCLEVBQUUsQ0FBQ2lDLE1BQWpDLENBQVo7TUFDQWpDLEVBQUUsQ0FBQzhCLEdBQUgsQ0FBT0MsTUFBUDtNQUNBL0IsRUFBRSxDQUFDOEIsR0FBSCxDQUFPLEtBQUtYLElBQUwsQ0FBVUgsZ0JBQWpCO01BQ0FlLE1BQU0sQ0FBQ0csV0FBUCxHQUFxQixLQUFLbEIsZ0JBQTFCO01BQ0FoQixFQUFFLENBQUM4QixHQUFILENBQU8sU0FBUDtNQUNBckMsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixJQUEzQjtJQUNIO0VBQ0osQ0FwSUk7RUFxSUo7RUFDQTtFQUNBO0VBRUR5QyxLQXpJSyxtQkF5SUksQ0FFUixDQTNJSSxDQTZJTDs7QUE3SUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbndpbmRvdy5sb2NrT2ZDbG9zZXRJbkNQMSA9IGZhbHNlO1xubGV0IHJlczEgPTA7bGV0IHJlczIgPTA7IGxldCByZXMzID0wIDtsZXQgcmVzNCA9MDtsZXQgcmVzID1cIlwiO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc3ByaXRlX0ZyYW1lMSA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWUyIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH0sXG4gICAgICAgIHNwcml0ZV9GcmFtZTMgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lNCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTUgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lNiA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTcgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lOCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTkgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lMCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWVPcGVuIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG4gICAgY2xvc2V0MSgpe1xuICAgICAgICBsZXQgYnV0dG9uMSA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIHN3aXRjaCAocmVzMSkge1xuICAgICAgICAgICAgY2FzZSAwIDogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTE7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDEgOiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMjticmVhaztcbiAgICAgICAgICAgIGNhc2UgMjogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU0O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA0IDogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTU7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDU6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU2O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA2OiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNzogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTg7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDg6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU5O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA5OiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczEgKys7XG4gICAgICAgIGlmKHJlczE9PT0xMCl7XG4gICAgICAgICAgICByZXMxPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDIoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjIgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXMyKSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczIgKys7XG4gICAgICAgIGlmKHJlczI9PT0xMCl7XG4gICAgICAgICAgICByZXMyPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDMoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjMgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXMzKSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczMgKys7XG4gICAgICAgIGlmKHJlczM9PT0xMCl7XG4gICAgICAgICAgICByZXMzPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDQoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjQgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXM0KSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczQgKys7XG4gICAgICAgIGlmKHJlczQ9PT0xMCl7XG4gICAgICAgICAgICByZXM0PTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldEp1ZGdlKCl7XG4gICAgICAgIHJlcyA9JycrcmVzMStyZXMyK3JlczMrcmVzNDtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgICAgIGlmKHJlcz09PVwiMDAwMlwiKXtcbiAgICAgICAgICAgIGxldCBjbG9zZXQgPXRoaXMubm9kZS5wYXJlbnQuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgICAgICBjYy5sb2coY2xvc2V0KVxuICAgICAgICAgICAgY2MubG9nKHRoaXMubm9kZS5zcHJpdGVfRnJhbWVPcGVuKVxuICAgICAgICAgICAgY2xvc2V0LnNwcml0ZUZyYW1lID0gdGhpcy5zcHJpdGVfRnJhbWVPcGVuO1xuICAgICAgICAgICAgY2MubG9nKFwic3VjY2Vzc1wiKTtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NrT2ZDbG9zZXRJbkNQMSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICAvLyBvbkxvYWQgKCkge1xuICAgICAvL1xuICAgICAvLyB9LFxuXG4gICAgc3RhcnQgKCkge1xuXG4gICAgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=