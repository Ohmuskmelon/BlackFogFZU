
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/stairlock.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c640a8cGOxEOonjHxqGcC7T', 'stairlock');
// script/stairlock.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var res1 = 1;
var res2 = 2;
var res3 = 3;
var res4 = 4;
var res5 = 5;
var res6 = 6;
var res7 = 7;
var res8 = 8;
var res9 = 9;
var res = "";
window.lockOfStairsInCP0 = false;
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  stairLock1: function stairLock1() {
    res = res + res1;
    cc.log(res);
  },
  stairLock2: function stairLock2() {
    res = res + res2;
    cc.log(res);
  },
  stairLock3: function stairLock3() {
    res = res + res3;
    cc.log(res);
  },
  stairLock4: function stairLock4() {
    res = res + res4;
    cc.log(res);
  },
  stairLock5: function stairLock5() {
    res = res + res5;
    cc.log(res);
  },
  stairLock6: function stairLock6() {
    res = res + res6;
    cc.log(res);
  },
  stairLock7: function stairLock7() {
    res = res + res7;
    cc.log(res);
  },
  stairLock8: function stairLock8() {
    res = res + res8;
    cc.log(res);
  },
  stairLock9: function stairLock9() {
    res = res + res9;
    cc.log(res);
  },
  stairLockJudge: function stairLockJudge() {
    if (res.length < 4) {
      cc.log(res);
    } else if (res.length === 4 && res === "9882") {
      cc.log("success");
      window.lockOfStairsInCP0 = true;
    } else {
      cc.log("fail");
      res = "";
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxzdGFpcmxvY2suanMiXSwibmFtZXMiOlsicmVzMSIsInJlczIiLCJyZXMzIiwicmVzNCIsInJlczUiLCJyZXM2IiwicmVzNyIsInJlczgiLCJyZXM5IiwicmVzIiwid2luZG93IiwibG9ja09mU3RhaXJzSW5DUDAiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YWlyTG9jazEiLCJsb2ciLCJzdGFpckxvY2syIiwic3RhaXJMb2NrMyIsInN0YWlyTG9jazQiLCJzdGFpckxvY2s1Iiwic3RhaXJMb2NrNiIsInN0YWlyTG9jazciLCJzdGFpckxvY2s4Iiwic3RhaXJMb2NrOSIsInN0YWlyTG9ja0p1ZGdlIiwibGVuZ3RoIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUEsSUFBSSxHQUFFLENBQVY7QUFBYSxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQzFCLElBQUlDLElBQUksR0FBRyxDQUFYO0FBQWMsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFBYyxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUM1QixJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFjLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQWMsSUFBSUMsSUFBSSxHQUFFLENBQVY7QUFDNUIsSUFBSUMsR0FBRyxHQUFHLEVBQVY7QUFDQUMsTUFBTSxDQUFDQyxpQkFBUCxHQUEwQixLQUExQjtBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUUsQ0FDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7RUFmUSxDQUhQO0VBb0JMQyxVQXBCSyx3QkFvQlE7SUFDVFAsR0FBRyxHQUFFQSxHQUFHLEdBQUNULElBQVQ7SUFFQVksRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQXhCSTtFQXlCTFMsVUF6Qkssd0JBeUJRO0lBQ1RULEdBQUcsR0FBRUEsR0FBRyxHQUFDUixJQUFUO0lBQ0FXLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0E1Qkk7RUE2QkxVLFVBN0JLLHdCQTZCUTtJQUNUVixHQUFHLEdBQUVBLEdBQUcsR0FBQ1AsSUFBVDtJQUNBVSxFQUFFLENBQUNLLEdBQUgsQ0FBT1IsR0FBUDtFQUNILENBaENJO0VBaUNMVyxVQWpDSyx3QkFpQ1E7SUFDVFgsR0FBRyxHQUFFQSxHQUFHLEdBQUNOLElBQVQ7SUFDQVMsRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQXBDSTtFQXFDTFksVUFyQ0ssd0JBcUNRO0lBQ1RaLEdBQUcsR0FBRUEsR0FBRyxHQUFDTCxJQUFUO0lBQ0FRLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0F4Q0k7RUF5Q0xhLFVBekNLLHdCQXlDUTtJQUNUYixHQUFHLEdBQUVBLEdBQUcsR0FBQ0osSUFBVDtJQUNBTyxFQUFFLENBQUNLLEdBQUgsQ0FBT1IsR0FBUDtFQUNILENBNUNJO0VBNkNMYyxVQTdDSyx3QkE2Q1E7SUFDVGQsR0FBRyxHQUFFQSxHQUFHLEdBQUNILElBQVQ7SUFDQU0sRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQWhESTtFQWlETGUsVUFqREssd0JBaURRO0lBQ1RmLEdBQUcsR0FBRUEsR0FBRyxHQUFDRixJQUFUO0lBQ0FLLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0FwREk7RUFxRExnQixVQXJESyx3QkFxRFE7SUFDVGhCLEdBQUcsR0FBRUEsR0FBRyxHQUFDRCxJQUFUO0lBQ0FJLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0F4REk7RUF5RExpQixjQXpESyw0QkF5RFk7SUFDYixJQUFHakIsR0FBRyxDQUFDa0IsTUFBSixHQUFXLENBQWQsRUFBZ0I7TUFDWmYsRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7SUFDSCxDQUZELE1BR0ssSUFBR0EsR0FBRyxDQUFDa0IsTUFBSixLQUFhLENBQWIsSUFBaUJsQixHQUFHLEtBQUcsTUFBMUIsRUFBa0M7TUFDbkNHLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPLFNBQVA7TUFDQVAsTUFBTSxDQUFDQyxpQkFBUCxHQUEwQixJQUExQjtJQUNILENBSEksTUFHQztNQUNGQyxFQUFFLENBQUNLLEdBQUgsQ0FBTyxNQUFQO01BQ0FSLEdBQUcsR0FBRSxFQUFMO0lBQ0g7RUFDSixDQXBFSTtFQXFFTDtFQUVBO0VBRUFtQixLQXpFSyxtQkF5RUksQ0FFUixDQTNFSSxDQTZFTDs7QUE3RUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbmxldCByZXMxID0xIDtsZXQgcmVzMiA9MiA7bGV0IHJlczMgPTMgO1xubGV0IHJlczQgPSA0OyBsZXQgcmVzNSA9IDU7IGxldCByZXM2ID02IDtcbmxldCByZXM3ID03IDsgbGV0IHJlczggPTggOyBsZXQgcmVzOSA9OSA7XG5sZXQgcmVzID0gXCJcIjtcbndpbmRvdy5sb2NrT2ZTdGFpcnNJbkNQMCA9ZmFsc2U7XG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gYmFyOiB7XG4gICAgICAgIC8vICAgICBnZXQgKCkge1xuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XG4gICAgICAgIC8vICAgICB9LFxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9LFxuICAgIH0sXG4gICAgc3RhaXJMb2NrMSAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzMTtcblxuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazIgKCl7XG4gICAgICAgIHJlcyA9cmVzK3JlczI7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrMyAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzMztcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2s0ICgpe1xuICAgICAgICByZXMgPXJlcytyZXM0O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazUgKCl7XG4gICAgICAgIHJlcyA9cmVzK3JlczU7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrNiAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzNjtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2s3ICgpe1xuICAgICAgICByZXMgPXJlcytyZXM3O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazggKCl7XG4gICAgICAgIHJlcyA9cmVzK3Jlczg7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrOSAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzOTtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2tKdWRnZSAoKXtcbiAgICAgICAgaWYocmVzLmxlbmd0aDw0KXtcbiAgICAgICAgICAgIGNjLmxvZyhyZXMpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihyZXMubGVuZ3RoPT09NCYmKHJlcz09PVwiOTg4MlwiKSl7XG4gICAgICAgICAgICBjYy5sb2coXCJzdWNjZXNzXCIpXG4gICAgICAgICAgICB3aW5kb3cubG9ja09mU3RhaXJzSW5DUDAgPXRydWU7XG4gICAgICAgIH1lbHNlIHtcbiAgICAgICAgICAgIGNjLmxvZyhcImZhaWxcIilcbiAgICAgICAgICAgIHJlcyA9XCJcIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyBvbkxvYWQgKCkge30sXG5cbiAgICBzdGFydCAoKSB7XG5cbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbiJdfQ==