
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/switch.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'efbe1Uv2OtAB5rrrirEZfoB', 'switch');
// script/switch.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

/*
电闸
 */
window.lockOfSwitchInCP1 = false;
var res1 = 1;
var res2 = 1;
var res3 = -1;
var res4 = 1;
var res5 = -1;
var res6 = 1;
var res7 = 1;
var res8 = -1;
cc.Class({
  "extends": cc.Component,
  properties: {
    sprite_Frame1: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame2: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  switch1: function switch1() {
    var button1 = this.node.getComponent(cc.Button);
    res1 = -res1;

    if (res1 === 1) {
      button1.normalSprite = this.sprite_Frame1;
    } else {
      button1.normalSprite = this.sprite_Frame2;
    }

    cc.log("res1" + res1);
  },
  switch2: function switch2() {
    var button2 = this.node.getComponent(cc.Button);
    res2 = -res2;

    if (res2 === 1) {
      button2.normalSprite = this.sprite_Frame1;
    } else {
      button2.normalSprite = this.sprite_Frame2;
    }

    cc.log("res2" + res2);
  },
  switch3: function switch3() {
    var button3 = this.node.getComponent(cc.Button);

    if (res3 === 1) {
      button3.normalSprite = this.sprite_Frame1;
    } else {
      button3.normalSprite = this.sprite_Frame2;
    }

    res3 = -res3;
    cc.log(res3);
  },
  switch4: function switch4() {
    var button4 = this.node.getComponent(cc.Button);

    if (res4 === 1) {
      button4.normalSprite = this.sprite_Frame1;
    } else {
      button4.normalSprite = this.sprite_Frame2;
    }

    res4 = -res4;
    cc.log(res4);
  },
  switch5: function switch5() {
    var button5 = this.node.getComponent(cc.Button);

    if (res5 === 1) {
      button5.normalSprite = this.sprite_Frame1;
    } else {
      button5.normalSprite = this.sprite_Frame2;
    }

    res5 = -res5;
    cc.log(res5);
  },
  switch6: function switch6() {
    var button6 = this.node.getComponent(cc.Button);

    if (res6 === 1) {
      button6.normalSprite = this.sprite_Frame1;
    } else {
      button6.normalSprite = this.sprite_Frame2;
    }

    res6 = -res6;
    cc.log(res6);
  },
  switch7: function switch7() {
    var button7 = this.node.getComponent(cc.Button);

    if (res7 === 1) {
      button7.normalSprite = this.sprite_Frame1;
    } else {
      button7.normalSprite = this.sprite_Frame2;
    }

    res7 = -res7;
    cc.log(res7);
  },
  switch8: function switch8() {
    var button8 = this.node.getComponent(cc.Button);

    if (res8 == 1) {
      button8.normalSprite = this.sprite_Frame1;
    } else {
      button8.normalSprite = this.sprite_Frame2;
    }

    res8 = -res8;
    cc.log(res8);
  },
  switch9: function switch9() {
    if (res1 + res3 + res2 + res4 + res5 + res6 + res7 + res8 == 8) {
      window.lockOfSwitchInCP1 = false;
      cc.log("success");
    }

    ;
    cc.log(res1 + res3 + res2 + res4 + res5 + res6 + res7 + res8);
  },
  onLoad: function onLoad() {// cc.resources.load('switch1')
    //  cc.resources.load('switch2')
    // this.sprites =  cc.resources.load("resources/2.png")
    //  console.log(this.sprites);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxzd2l0Y2guanMiXSwibmFtZXMiOlsid2luZG93IiwibG9ja09mU3dpdGNoSW5DUDEiLCJyZXMxIiwicmVzMiIsInJlczMiLCJyZXM0IiwicmVzNSIsInJlczYiLCJyZXM3IiwicmVzOCIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3ByaXRlX0ZyYW1lMSIsInR5cGUiLCJTcHJpdGVGcmFtZSIsInNwcml0ZV9GcmFtZTIiLCJzd2l0Y2gxIiwiYnV0dG9uMSIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJCdXR0b24iLCJub3JtYWxTcHJpdGUiLCJsb2ciLCJzd2l0Y2gyIiwiYnV0dG9uMiIsInN3aXRjaDMiLCJidXR0b24zIiwic3dpdGNoNCIsImJ1dHRvbjQiLCJzd2l0Y2g1IiwiYnV0dG9uNSIsInN3aXRjaDYiLCJidXR0b242Iiwic3dpdGNoNyIsImJ1dHRvbjciLCJzd2l0Y2g4IiwiYnV0dG9uOCIsInN3aXRjaDkiLCJvbkxvYWQiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0FBLE1BQU0sQ0FBQ0MsaUJBQVAsR0FBMkIsS0FBM0I7QUFDQSxJQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQy9ELElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUNaQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUU7SUFFUkMsYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhDLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFLENBRlA7SUFNUkMsYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhGLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFO0VBTlAsQ0FIUDtFQWVMRSxPQWZLLHFCQWVLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixDQUFiO0lBQ0FwQixJQUFJLEdBQUUsQ0FBQ0EsSUFBUDs7SUFDQSxJQUFHQSxJQUFJLEtBQUcsQ0FBVixFQUFZO01BQ1JpQixPQUFPLENBQUNJLFlBQVIsR0FBdUIsS0FBS1QsYUFBNUI7SUFDSCxDQUZELE1BRUs7TUFDREssT0FBTyxDQUFDSSxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBRURQLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPLFNBQU90QixJQUFkO0VBRUgsQ0ExQkk7RUEyQkx1QixPQTNCSyxxQkEyQks7SUFDTixJQUFJQyxPQUFPLEdBQUUsS0FBS04sSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7SUFDQW5CLElBQUksR0FBRSxDQUFDQSxJQUFQOztJQUNBLElBQUdBLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUnVCLE9BQU8sQ0FBQ0gsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEWSxPQUFPLENBQUNILFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFFRFAsRUFBRSxDQUFDYyxHQUFILENBQU8sU0FBT3JCLElBQWQ7RUFDSCxDQXJDSTtFQXNDTHdCLE9BdENLLHFCQXNDSztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLUixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHbEIsSUFBSSxLQUFHLENBQVYsRUFBWTtNQUNSd0IsT0FBTyxDQUFDTCxZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0RjLE9BQU8sQ0FBQ0wsWUFBUixHQUF1QixLQUFLTixhQUE1QjtJQUNIOztJQUNEYixJQUFJLEdBQUUsQ0FBQ0EsSUFBUDtJQUNBTSxFQUFFLENBQUNjLEdBQUgsQ0FBT3BCLElBQVA7RUFDSCxDQWhESTtFQWlETHlCLE9BakRLLHFCQWlESztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLVixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHakIsSUFBSSxLQUFHLENBQVYsRUFBWTtNQUNSeUIsT0FBTyxDQUFDUCxZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0RnQixPQUFPLENBQUNQLFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFDRFosSUFBSSxHQUFFLENBQUNBLElBQVA7SUFDQUssRUFBRSxDQUFDYyxHQUFILENBQU9uQixJQUFQO0VBQ0gsQ0EzREk7RUE0REwwQixPQTVESyxxQkE0REs7SUFDTixJQUFJQyxPQUFPLEdBQUUsS0FBS1osSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7O0lBRUEsSUFBR2hCLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUjBCLE9BQU8sQ0FBQ1QsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEa0IsT0FBTyxDQUFDVCxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBQ0RYLElBQUksR0FBRSxDQUFDQSxJQUFQO0lBQ0FJLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPbEIsSUFBUDtFQUNILENBdEVJO0VBdUVMMkIsT0F2RUsscUJBdUVLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtkLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixDQUFiOztJQUVBLElBQUdmLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUjJCLE9BQU8sQ0FBQ1gsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEb0IsT0FBTyxDQUFDWCxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBQ0RWLElBQUksR0FBRSxDQUFDQSxJQUFQO0lBQ0FHLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPakIsSUFBUDtFQUNILENBakZJO0VBa0ZMNEIsT0FsRksscUJBa0ZLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtoQixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHZCxJQUFJLEtBQUcsQ0FBVixFQUFZO01BQ1I0QixPQUFPLENBQUNiLFlBQVIsR0FBdUIsS0FBS1QsYUFBNUI7SUFDSCxDQUZELE1BRUs7TUFDRHNCLE9BQU8sQ0FBQ2IsWUFBUixHQUF1QixLQUFLTixhQUE1QjtJQUNIOztJQUNEVCxJQUFJLEdBQUUsQ0FBQ0EsSUFBUDtJQUNBRSxFQUFFLENBQUNjLEdBQUgsQ0FBT2hCLElBQVA7RUFDSCxDQTVGSTtFQTZGTDZCLE9BN0ZLLHFCQTZGSztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLbEIsSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7O0lBRUEsSUFBR2IsSUFBSSxJQUFFLENBQVQsRUFBVztNQUNQNkIsT0FBTyxDQUFDZixZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0R3QixPQUFPLENBQUNmLFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFDRFIsSUFBSSxHQUFFLENBQUNBLElBQVA7SUFDQUMsRUFBRSxDQUFDYyxHQUFILENBQU9mLElBQVA7RUFDSCxDQXZHSTtFQXdHTDhCLE9BeEdLLHFCQXdHSztJQUVOLElBQUlyQyxJQUFJLEdBQUNFLElBQUwsR0FBVUQsSUFBVixHQUFlRSxJQUFmLEdBQW9CQyxJQUFwQixHQUF5QkMsSUFBekIsR0FBOEJDLElBQTlCLEdBQW1DQyxJQUFwQyxJQUEyQyxDQUE5QyxFQUFnRDtNQUM1Q1QsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixLQUEzQjtNQUNBUyxFQUFFLENBQUNjLEdBQUgsQ0FBTyxTQUFQO0lBQ0g7O0lBQUE7SUFDRGQsRUFBRSxDQUFDYyxHQUFILENBQU90QixJQUFJLEdBQUNFLElBQUwsR0FBVUQsSUFBVixHQUFlRSxJQUFmLEdBQW9CQyxJQUFwQixHQUF5QkMsSUFBekIsR0FBOEJDLElBQTlCLEdBQW1DQyxJQUExQztFQUVILENBaEhJO0VBa0hKK0IsTUFsSEksb0JBa0hNLENBQ047SUFDQTtJQUNEO0lBQ0E7RUFDRixDQXZIRztFQXlITEMsS0F6SEssbUJBeUhJLENBRVIsQ0EzSEksQ0E2SEw7O0FBN0hLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxuLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbi8qXG7nlLXpl7hcbiAqL1xud2luZG93LmxvY2tPZlN3aXRjaEluQ1AxID0gZmFsc2U7XG5sZXQgcmVzMSA9IDE7bGV0IHJlczIgPTE7bGV0IHJlczMgPS0xO2xldCByZXM0ID0xO2xldCByZXM1ID0tMTtsZXQgcmVzNiA9MTtcbmxldCByZXM3ID0xO2xldCByZXM4ID0tMTtcbmNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG5cbiAgICAgICAgc3ByaXRlX0ZyYW1lMSA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWUyIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgc3dpdGNoMSAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjEgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgcmVzMSA9LXJlczE7XG4gICAgICAgIGlmKHJlczE9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInJlczFcIityZXMxKTtcblxuICAgIH0sXG4gICAgc3dpdGNoMiAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjIgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgcmVzMiA9LXJlczI7XG4gICAgICAgIGlmKHJlczI9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInJlczJcIityZXMyKTtcbiAgICB9LFxuICAgIHN3aXRjaDMgKCl7XG4gICAgICAgIGxldCBidXR0b24zID10aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG5cbiAgICAgICAgaWYocmVzMz09PTEpe1xuICAgICAgICAgICAgYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTFcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMlxuICAgICAgICB9XG4gICAgICAgIHJlczMgPS1yZXMzO1xuICAgICAgICBjYy5sb2cocmVzMyk7XG4gICAgfSxcbiAgICBzd2l0Y2g0ICgpe1xuICAgICAgICBsZXQgYnV0dG9uNCA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIGlmKHJlczQ9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM0ID0tcmVzNDtcbiAgICAgICAgY2MubG9nKHJlczQpO1xuICAgIH0sXG4gICAgc3dpdGNoNSAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjUgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcblxuICAgICAgICBpZihyZXM1PT09MSl7XG4gICAgICAgICAgICBidXR0b241Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMVxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIGJ1dHRvbjUubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyXG4gICAgICAgIH1cbiAgICAgICAgcmVzNSA9LXJlczU7XG4gICAgICAgIGNjLmxvZyhyZXM1KTtcbiAgICB9LFxuICAgIHN3aXRjaDYgKCl7XG4gICAgICAgIGxldCBidXR0b242ID10aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG5cbiAgICAgICAgaWYocmVzNj09PTEpe1xuICAgICAgICAgICAgYnV0dG9uNi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTFcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBidXR0b242Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMlxuICAgICAgICB9XG4gICAgICAgIHJlczYgPS1yZXM2O1xuICAgICAgICBjYy5sb2cocmVzNik7XG4gICAgfSxcbiAgICBzd2l0Y2g3ICgpe1xuICAgICAgICBsZXQgYnV0dG9uNyA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIGlmKHJlczc9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjcubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uNy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM3ID0tcmVzNztcbiAgICAgICAgY2MubG9nKHJlczcpO1xuICAgIH0sXG4gICAgc3dpdGNoOCAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjggPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcblxuICAgICAgICBpZihyZXM4PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjgubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uOC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM4ID0tcmVzODtcbiAgICAgICAgY2MubG9nKHJlczgpO1xuICAgIH0sXG4gICAgc3dpdGNoOSAoKXtcblxuICAgICAgICBpZigocmVzMStyZXMzK3JlczIrcmVzNCtyZXM1K3JlczYrcmVzNytyZXM4KT09OCl7XG4gICAgICAgICAgICB3aW5kb3cubG9ja09mU3dpdGNoSW5DUDEgPSBmYWxzZTtcbiAgICAgICAgICAgIGNjLmxvZyhcInN1Y2Nlc3NcIik7XG4gICAgICAgIH07XG4gICAgICAgIGNjLmxvZyhyZXMxK3JlczMrcmVzMityZXM0K3JlczUrcmVzNityZXM3K3JlczgpXG5cbiAgICB9LFxuXG4gICAgIG9uTG9hZCAoKSB7XG4gICAgICAgICAvLyBjYy5yZXNvdXJjZXMubG9hZCgnc3dpdGNoMScpXG4gICAgICAgICAvLyAgY2MucmVzb3VyY2VzLmxvYWQoJ3N3aXRjaDInKVxuICAgICAgICAvLyB0aGlzLnNwcml0ZXMgPSAgY2MucmVzb3VyY2VzLmxvYWQoXCJyZXNvdXJjZXMvMi5wbmdcIilcbiAgICAgICAgLy8gIGNvbnNvbGUubG9nKHRoaXMuc3ByaXRlcyk7XG4gICAgIH0sXG5cbiAgICBzdGFydCAoKSB7XG5cbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbiJdfQ==