
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/gate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ed596AnlUhLvrXw8KerKm5A', 'gate');
// script/gate.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle gate
window.lockOfGateCP1 = false;
var _gate = 1;
var _gate2 = 2;
var _gate3 = 3;
var _gate4 = 4;
var _gate5 = 5;
var _gate6 = 6;
var _gate7 = 7;
var _gate8 = 8;
var _gate9 = 9;
var res = "";
cc.Class({
  "extends": cc.Component,
  properties: {},
  gate1: function gate1() {
    res = res + _gate;
    cc.log(res);
  },
  gate2: function gate2() {
    res = res + _gate2;
    cc.log(res);
  },
  gate3: function gate3() {
    res = res + _gate3;
    cc.log(res);
  },
  gate4: function gate4() {
    res = res + _gate4;
    cc.log(res);
  },
  gate5: function gate5() {
    res = res + _gate5;
    cc.log(res);
  },
  gate6: function gate6() {
    res = res + _gate6;
    cc.log(res);
  },
  gate7: function gate7() {
    res = res + _gate7;
    cc.log(res);
  },
  gate8: function gate8() {
    res = res + _gate8;
    cc.log(res);
  },
  gate9: function gate9() {
    res = res + _gate9;
    cc.log(res);
  },
  gateJudge: function gateJudge() {
    if (res.length < 4) {
      cc.log(res);
    } else if (res.length === 4 && res === "3682") {
      cc.log("success");
      window.lockOfGateCP1 = true;
    } else {
      cc.log("fail");
      res = "";
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxnYXRlLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsImxvY2tPZkdhdGVDUDEiLCJnYXRlMSIsImdhdGUyIiwiZ2F0ZTMiLCJnYXRlNCIsImdhdGU1IiwiZ2F0ZTYiLCJnYXRlNyIsImdhdGU4IiwiZ2F0ZTkiLCJyZXMiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImxvZyIsImdhdGVKdWRnZSIsImxlbmd0aCIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQUEsTUFBTSxDQUFDQyxhQUFQLEdBQXNCLEtBQXRCO0FBQ0EsSUFBSUMsS0FBSyxHQUFHLENBQVo7QUFBZSxJQUFJQyxNQUFLLEdBQUUsQ0FBWDtBQUFjLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQWlCLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQzlDLElBQUlDLE1BQUssR0FBRSxDQUFYO0FBQWEsSUFBSUMsTUFBSyxHQUFHLENBQVo7QUFBYyxJQUFJQyxNQUFLLEdBQUcsQ0FBWjtBQUFjLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQWMsSUFBSUMsTUFBSyxHQUFHLENBQVo7QUFBYyxJQUFJQyxHQUFHLEdBQUUsRUFBVDtBQUNyRUMsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNFLFNBRFA7RUFHTEMsVUFBVSxFQUFFLEVBSFA7RUFNTGIsS0FOSyxtQkFNRztJQUNKUyxHQUFHLEdBQUVBLEdBQUcsR0FBQ1QsS0FBVDtJQUVBVSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBVkk7RUFXTFIsS0FYSyxtQkFXRztJQUNKUSxHQUFHLEdBQUVBLEdBQUcsR0FBQ1IsTUFBVDtJQUNBUyxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBZEk7RUFlTFAsS0FmSyxtQkFlRztJQUNKTyxHQUFHLEdBQUVBLEdBQUcsR0FBQ1AsTUFBVDtJQUNBUSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBbEJJO0VBbUJMTixLQW5CSyxtQkFtQkc7SUFDSk0sR0FBRyxHQUFFQSxHQUFHLEdBQUNOLE1BQVQ7SUFDQU8sRUFBRSxDQUFDSSxHQUFILENBQU9MLEdBQVA7RUFDSCxDQXRCSTtFQXVCTEwsS0F2QkssbUJBdUJHO0lBQ0pLLEdBQUcsR0FBRUEsR0FBRyxHQUFDTCxNQUFUO0lBQ0FNLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0VBQ0gsQ0ExQkk7RUEyQkxKLEtBM0JLLG1CQTJCRztJQUNKSSxHQUFHLEdBQUVBLEdBQUcsR0FBQ0osTUFBVDtJQUNBSyxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBOUJJO0VBK0JMSCxLQS9CSyxtQkErQkc7SUFDSkcsR0FBRyxHQUFFQSxHQUFHLEdBQUNILE1BQVQ7SUFDQUksRUFBRSxDQUFDSSxHQUFILENBQU9MLEdBQVA7RUFDSCxDQWxDSTtFQW1DTEYsS0FuQ0ssbUJBbUNHO0lBQ0pFLEdBQUcsR0FBRUEsR0FBRyxHQUFDRixNQUFUO0lBQ0FHLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0VBQ0gsQ0F0Q0k7RUF1Q0xELEtBdkNLLG1CQXVDRztJQUNKQyxHQUFHLEdBQUVBLEdBQUcsR0FBQ0QsTUFBVDtJQUNBRSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBMUNJO0VBMkNMTSxTQTNDSyx1QkEyQ087SUFDUixJQUFHTixHQUFHLENBQUNPLE1BQUosR0FBVyxDQUFkLEVBQWdCO01BQ1pOLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0lBQ0gsQ0FGRCxNQUdLLElBQUdBLEdBQUcsQ0FBQ08sTUFBSixLQUFhLENBQWIsSUFBaUJQLEdBQUcsS0FBRyxNQUExQixFQUFrQztNQUNuQ0MsRUFBRSxDQUFDSSxHQUFILENBQU8sU0FBUDtNQUNBaEIsTUFBTSxDQUFDQyxhQUFQLEdBQXNCLElBQXRCO0lBQ0gsQ0FISSxNQUdDO01BQ0ZXLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPLE1BQVA7TUFDQUwsR0FBRyxHQUFFLEVBQUw7SUFDSDtFQUNKLENBdERJO0VBeURMUSxLQXpESyxtQkF5REksQ0FFUixDQTNESSxDQTZETDs7QUE3REssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGdhdGVcblxuXG53aW5kb3cubG9ja09mR2F0ZUNQMSA9ZmFsc2U7XG5sZXQgZ2F0ZTEgPSAxOyBsZXQgZ2F0ZTIgPTIgO2xldCBnYXRlMyA9IDMgOyAgbGV0IGdhdGU0ID0gNDtcbmxldCBnYXRlNSA9NTtsZXQgZ2F0ZTYgPSA2O2xldCBnYXRlNyA9IDc7bGV0IGdhdGU4ID0gODtsZXQgZ2F0ZTkgPSA5O2xldCByZXMgPVwiXCI7XG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgfSxcbiAgICBnYXRlMSAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTE7XG5cbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlMiAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTI7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTMgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGUzO1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGU0ICgpe1xuICAgICAgICByZXMgPXJlcytnYXRlNDtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlNSAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTU7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTYgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGU2O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGU3ICgpe1xuICAgICAgICByZXMgPXJlcytnYXRlNztcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlOCAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTg7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTkgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGU5O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGVKdWRnZSAoKXtcbiAgICAgICAgaWYocmVzLmxlbmd0aDw0KXtcbiAgICAgICAgICAgIGNjLmxvZyhyZXMpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihyZXMubGVuZ3RoPT09NCYmKHJlcz09PVwiMzY4MlwiKSl7XG4gICAgICAgICAgICBjYy5sb2coXCJzdWNjZXNzXCIpXG4gICAgICAgICAgICB3aW5kb3cubG9ja09mR2F0ZUNQMSA9dHJ1ZTtcbiAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgY2MubG9nKFwiZmFpbFwiKVxuICAgICAgICAgICAgcmVzID1cIlwiO1xuICAgICAgICB9XG4gICAgfSxcblxuXG4gICAgc3RhcnQgKCkge1xuXG4gICAgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=