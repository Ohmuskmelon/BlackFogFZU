
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/script/closet');
require('./assets/script/gate');
require('./assets/script/stairlock');
require('./assets/script/switch');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/gate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ed596AnlUhLvrXw8KerKm5A', 'gate');
// script/gate.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle gate
window.lockOfGateCP1 = false;
var _gate = 1;
var _gate2 = 2;
var _gate3 = 3;
var _gate4 = 4;
var _gate5 = 5;
var _gate6 = 6;
var _gate7 = 7;
var _gate8 = 8;
var _gate9 = 9;
var res = "";
cc.Class({
  "extends": cc.Component,
  properties: {},
  gate1: function gate1() {
    res = res + _gate;
    cc.log(res);
  },
  gate2: function gate2() {
    res = res + _gate2;
    cc.log(res);
  },
  gate3: function gate3() {
    res = res + _gate3;
    cc.log(res);
  },
  gate4: function gate4() {
    res = res + _gate4;
    cc.log(res);
  },
  gate5: function gate5() {
    res = res + _gate5;
    cc.log(res);
  },
  gate6: function gate6() {
    res = res + _gate6;
    cc.log(res);
  },
  gate7: function gate7() {
    res = res + _gate7;
    cc.log(res);
  },
  gate8: function gate8() {
    res = res + _gate8;
    cc.log(res);
  },
  gate9: function gate9() {
    res = res + _gate9;
    cc.log(res);
  },
  gateJudge: function gateJudge() {
    if (res.length < 4) {
      cc.log(res);
    } else if (res.length === 4 && res === "3682") {
      cc.log("success");
      window.lockOfGateCP1 = true;
    } else {
      cc.log("fail");
      res = "";
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxnYXRlLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsImxvY2tPZkdhdGVDUDEiLCJnYXRlMSIsImdhdGUyIiwiZ2F0ZTMiLCJnYXRlNCIsImdhdGU1IiwiZ2F0ZTYiLCJnYXRlNyIsImdhdGU4IiwiZ2F0ZTkiLCJyZXMiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImxvZyIsImdhdGVKdWRnZSIsImxlbmd0aCIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQUEsTUFBTSxDQUFDQyxhQUFQLEdBQXNCLEtBQXRCO0FBQ0EsSUFBSUMsS0FBSyxHQUFHLENBQVo7QUFBZSxJQUFJQyxNQUFLLEdBQUUsQ0FBWDtBQUFjLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQWlCLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQzlDLElBQUlDLE1BQUssR0FBRSxDQUFYO0FBQWEsSUFBSUMsTUFBSyxHQUFHLENBQVo7QUFBYyxJQUFJQyxNQUFLLEdBQUcsQ0FBWjtBQUFjLElBQUlDLE1BQUssR0FBRyxDQUFaO0FBQWMsSUFBSUMsTUFBSyxHQUFHLENBQVo7QUFBYyxJQUFJQyxHQUFHLEdBQUUsRUFBVDtBQUNyRUMsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNFLFNBRFA7RUFHTEMsVUFBVSxFQUFFLEVBSFA7RUFNTGIsS0FOSyxtQkFNRztJQUNKUyxHQUFHLEdBQUVBLEdBQUcsR0FBQ1QsS0FBVDtJQUVBVSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBVkk7RUFXTFIsS0FYSyxtQkFXRztJQUNKUSxHQUFHLEdBQUVBLEdBQUcsR0FBQ1IsTUFBVDtJQUNBUyxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBZEk7RUFlTFAsS0FmSyxtQkFlRztJQUNKTyxHQUFHLEdBQUVBLEdBQUcsR0FBQ1AsTUFBVDtJQUNBUSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBbEJJO0VBbUJMTixLQW5CSyxtQkFtQkc7SUFDSk0sR0FBRyxHQUFFQSxHQUFHLEdBQUNOLE1BQVQ7SUFDQU8sRUFBRSxDQUFDSSxHQUFILENBQU9MLEdBQVA7RUFDSCxDQXRCSTtFQXVCTEwsS0F2QkssbUJBdUJHO0lBQ0pLLEdBQUcsR0FBRUEsR0FBRyxHQUFDTCxNQUFUO0lBQ0FNLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0VBQ0gsQ0ExQkk7RUEyQkxKLEtBM0JLLG1CQTJCRztJQUNKSSxHQUFHLEdBQUVBLEdBQUcsR0FBQ0osTUFBVDtJQUNBSyxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBOUJJO0VBK0JMSCxLQS9CSyxtQkErQkc7SUFDSkcsR0FBRyxHQUFFQSxHQUFHLEdBQUNILE1BQVQ7SUFDQUksRUFBRSxDQUFDSSxHQUFILENBQU9MLEdBQVA7RUFDSCxDQWxDSTtFQW1DTEYsS0FuQ0ssbUJBbUNHO0lBQ0pFLEdBQUcsR0FBRUEsR0FBRyxHQUFDRixNQUFUO0lBQ0FHLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0VBQ0gsQ0F0Q0k7RUF1Q0xELEtBdkNLLG1CQXVDRztJQUNKQyxHQUFHLEdBQUVBLEdBQUcsR0FBQ0QsTUFBVDtJQUNBRSxFQUFFLENBQUNJLEdBQUgsQ0FBT0wsR0FBUDtFQUNILENBMUNJO0VBMkNMTSxTQTNDSyx1QkEyQ087SUFDUixJQUFHTixHQUFHLENBQUNPLE1BQUosR0FBVyxDQUFkLEVBQWdCO01BQ1pOLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPTCxHQUFQO0lBQ0gsQ0FGRCxNQUdLLElBQUdBLEdBQUcsQ0FBQ08sTUFBSixLQUFhLENBQWIsSUFBaUJQLEdBQUcsS0FBRyxNQUExQixFQUFrQztNQUNuQ0MsRUFBRSxDQUFDSSxHQUFILENBQU8sU0FBUDtNQUNBaEIsTUFBTSxDQUFDQyxhQUFQLEdBQXNCLElBQXRCO0lBQ0gsQ0FISSxNQUdDO01BQ0ZXLEVBQUUsQ0FBQ0ksR0FBSCxDQUFPLE1BQVA7TUFDQUwsR0FBRyxHQUFFLEVBQUw7SUFDSDtFQUNKLENBdERJO0VBeURMUSxLQXpESyxtQkF5REksQ0FFUixDQTNESSxDQTZETDs7QUE3REssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGdhdGVcblxuXG53aW5kb3cubG9ja09mR2F0ZUNQMSA9ZmFsc2U7XG5sZXQgZ2F0ZTEgPSAxOyBsZXQgZ2F0ZTIgPTIgO2xldCBnYXRlMyA9IDMgOyAgbGV0IGdhdGU0ID0gNDtcbmxldCBnYXRlNSA9NTtsZXQgZ2F0ZTYgPSA2O2xldCBnYXRlNyA9IDc7bGV0IGdhdGU4ID0gODtsZXQgZ2F0ZTkgPSA5O2xldCByZXMgPVwiXCI7XG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgfSxcbiAgICBnYXRlMSAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTE7XG5cbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlMiAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTI7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTMgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGUzO1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGU0ICgpe1xuICAgICAgICByZXMgPXJlcytnYXRlNDtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlNSAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTU7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTYgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGU2O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGU3ICgpe1xuICAgICAgICByZXMgPXJlcytnYXRlNztcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBnYXRlOCAoKXtcbiAgICAgICAgcmVzID1yZXMrZ2F0ZTg7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgZ2F0ZTkgKCl7XG4gICAgICAgIHJlcyA9cmVzK2dhdGU5O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIGdhdGVKdWRnZSAoKXtcbiAgICAgICAgaWYocmVzLmxlbmd0aDw0KXtcbiAgICAgICAgICAgIGNjLmxvZyhyZXMpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihyZXMubGVuZ3RoPT09NCYmKHJlcz09PVwiMzY4MlwiKSl7XG4gICAgICAgICAgICBjYy5sb2coXCJzdWNjZXNzXCIpXG4gICAgICAgICAgICB3aW5kb3cubG9ja09mR2F0ZUNQMSA9dHJ1ZTtcbiAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgY2MubG9nKFwiZmFpbFwiKVxuICAgICAgICAgICAgcmVzID1cIlwiO1xuICAgICAgICB9XG4gICAgfSxcblxuXG4gICAgc3RhcnQgKCkge1xuXG4gICAgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/stairlock.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c640a8cGOxEOonjHxqGcC7T', 'stairlock');
// script/stairlock.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var res1 = 1;
var res2 = 2;
var res3 = 3;
var res4 = 4;
var res5 = 5;
var res6 = 6;
var res7 = 7;
var res8 = 8;
var res9 = 9;
var res = "";
window.lockOfStairsInCP0 = false;
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  stairLock1: function stairLock1() {
    res = res + res1;
    cc.log(res);
  },
  stairLock2: function stairLock2() {
    res = res + res2;
    cc.log(res);
  },
  stairLock3: function stairLock3() {
    res = res + res3;
    cc.log(res);
  },
  stairLock4: function stairLock4() {
    res = res + res4;
    cc.log(res);
  },
  stairLock5: function stairLock5() {
    res = res + res5;
    cc.log(res);
  },
  stairLock6: function stairLock6() {
    res = res + res6;
    cc.log(res);
  },
  stairLock7: function stairLock7() {
    res = res + res7;
    cc.log(res);
  },
  stairLock8: function stairLock8() {
    res = res + res8;
    cc.log(res);
  },
  stairLock9: function stairLock9() {
    res = res + res9;
    cc.log(res);
  },
  stairLockJudge: function stairLockJudge() {
    if (res.length < 4) {
      cc.log(res);
    } else if (res.length === 4 && res === "9882") {
      cc.log("success");
      window.lockOfStairsInCP0 = true;
    } else {
      cc.log("fail");
      res = "";
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxzdGFpcmxvY2suanMiXSwibmFtZXMiOlsicmVzMSIsInJlczIiLCJyZXMzIiwicmVzNCIsInJlczUiLCJyZXM2IiwicmVzNyIsInJlczgiLCJyZXM5IiwicmVzIiwid2luZG93IiwibG9ja09mU3RhaXJzSW5DUDAiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YWlyTG9jazEiLCJsb2ciLCJzdGFpckxvY2syIiwic3RhaXJMb2NrMyIsInN0YWlyTG9jazQiLCJzdGFpckxvY2s1Iiwic3RhaXJMb2NrNiIsInN0YWlyTG9jazciLCJzdGFpckxvY2s4Iiwic3RhaXJMb2NrOSIsInN0YWlyTG9ja0p1ZGdlIiwibGVuZ3RoIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUEsSUFBSSxHQUFFLENBQVY7QUFBYSxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQzFCLElBQUlDLElBQUksR0FBRyxDQUFYO0FBQWMsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFBYyxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUM1QixJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFjLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQWMsSUFBSUMsSUFBSSxHQUFFLENBQVY7QUFDNUIsSUFBSUMsR0FBRyxHQUFHLEVBQVY7QUFDQUMsTUFBTSxDQUFDQyxpQkFBUCxHQUEwQixLQUExQjtBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUUsQ0FDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7RUFmUSxDQUhQO0VBb0JMQyxVQXBCSyx3QkFvQlE7SUFDVFAsR0FBRyxHQUFFQSxHQUFHLEdBQUNULElBQVQ7SUFFQVksRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQXhCSTtFQXlCTFMsVUF6Qkssd0JBeUJRO0lBQ1RULEdBQUcsR0FBRUEsR0FBRyxHQUFDUixJQUFUO0lBQ0FXLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0E1Qkk7RUE2QkxVLFVBN0JLLHdCQTZCUTtJQUNUVixHQUFHLEdBQUVBLEdBQUcsR0FBQ1AsSUFBVDtJQUNBVSxFQUFFLENBQUNLLEdBQUgsQ0FBT1IsR0FBUDtFQUNILENBaENJO0VBaUNMVyxVQWpDSyx3QkFpQ1E7SUFDVFgsR0FBRyxHQUFFQSxHQUFHLEdBQUNOLElBQVQ7SUFDQVMsRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQXBDSTtFQXFDTFksVUFyQ0ssd0JBcUNRO0lBQ1RaLEdBQUcsR0FBRUEsR0FBRyxHQUFDTCxJQUFUO0lBQ0FRLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0F4Q0k7RUF5Q0xhLFVBekNLLHdCQXlDUTtJQUNUYixHQUFHLEdBQUVBLEdBQUcsR0FBQ0osSUFBVDtJQUNBTyxFQUFFLENBQUNLLEdBQUgsQ0FBT1IsR0FBUDtFQUNILENBNUNJO0VBNkNMYyxVQTdDSyx3QkE2Q1E7SUFDVGQsR0FBRyxHQUFFQSxHQUFHLEdBQUNILElBQVQ7SUFDQU0sRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7RUFDSCxDQWhESTtFQWlETGUsVUFqREssd0JBaURRO0lBQ1RmLEdBQUcsR0FBRUEsR0FBRyxHQUFDRixJQUFUO0lBQ0FLLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0FwREk7RUFxRExnQixVQXJESyx3QkFxRFE7SUFDVGhCLEdBQUcsR0FBRUEsR0FBRyxHQUFDRCxJQUFUO0lBQ0FJLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPUixHQUFQO0VBQ0gsQ0F4REk7RUF5RExpQixjQXpESyw0QkF5RFk7SUFDYixJQUFHakIsR0FBRyxDQUFDa0IsTUFBSixHQUFXLENBQWQsRUFBZ0I7TUFDWmYsRUFBRSxDQUFDSyxHQUFILENBQU9SLEdBQVA7SUFDSCxDQUZELE1BR0ssSUFBR0EsR0FBRyxDQUFDa0IsTUFBSixLQUFhLENBQWIsSUFBaUJsQixHQUFHLEtBQUcsTUFBMUIsRUFBa0M7TUFDbkNHLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPLFNBQVA7TUFDQVAsTUFBTSxDQUFDQyxpQkFBUCxHQUEwQixJQUExQjtJQUNILENBSEksTUFHQztNQUNGQyxFQUFFLENBQUNLLEdBQUgsQ0FBTyxNQUFQO01BQ0FSLEdBQUcsR0FBRSxFQUFMO0lBQ0g7RUFDSixDQXBFSTtFQXFFTDtFQUVBO0VBRUFtQixLQXpFSyxtQkF5RUksQ0FFUixDQTNFSSxDQTZFTDs7QUE3RUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbmxldCByZXMxID0xIDtsZXQgcmVzMiA9MiA7bGV0IHJlczMgPTMgO1xubGV0IHJlczQgPSA0OyBsZXQgcmVzNSA9IDU7IGxldCByZXM2ID02IDtcbmxldCByZXM3ID03IDsgbGV0IHJlczggPTggOyBsZXQgcmVzOSA9OSA7XG5sZXQgcmVzID0gXCJcIjtcbndpbmRvdy5sb2NrT2ZTdGFpcnNJbkNQMCA9ZmFsc2U7XG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gYmFyOiB7XG4gICAgICAgIC8vICAgICBnZXQgKCkge1xuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XG4gICAgICAgIC8vICAgICB9LFxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9LFxuICAgIH0sXG4gICAgc3RhaXJMb2NrMSAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzMTtcblxuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazIgKCl7XG4gICAgICAgIHJlcyA9cmVzK3JlczI7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrMyAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzMztcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2s0ICgpe1xuICAgICAgICByZXMgPXJlcytyZXM0O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazUgKCl7XG4gICAgICAgIHJlcyA9cmVzK3JlczU7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrNiAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzNjtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2s3ICgpe1xuICAgICAgICByZXMgPXJlcytyZXM3O1xuICAgICAgICBjYy5sb2cocmVzKTtcbiAgICB9LFxuICAgIHN0YWlyTG9jazggKCl7XG4gICAgICAgIHJlcyA9cmVzK3Jlczg7XG4gICAgICAgIGNjLmxvZyhyZXMpO1xuICAgIH0sXG4gICAgc3RhaXJMb2NrOSAoKXtcbiAgICAgICAgcmVzID1yZXMrcmVzOTtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgfSxcbiAgICBzdGFpckxvY2tKdWRnZSAoKXtcbiAgICAgICAgaWYocmVzLmxlbmd0aDw0KXtcbiAgICAgICAgICAgIGNjLmxvZyhyZXMpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihyZXMubGVuZ3RoPT09NCYmKHJlcz09PVwiOTg4MlwiKSl7XG4gICAgICAgICAgICBjYy5sb2coXCJzdWNjZXNzXCIpXG4gICAgICAgICAgICB3aW5kb3cubG9ja09mU3RhaXJzSW5DUDAgPXRydWU7XG4gICAgICAgIH1lbHNlIHtcbiAgICAgICAgICAgIGNjLmxvZyhcImZhaWxcIilcbiAgICAgICAgICAgIHJlcyA9XCJcIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyBvbkxvYWQgKCkge30sXG5cbiAgICBzdGFydCAoKSB7XG5cbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/closet.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '76dd1yUGTpPG6ZqkIbq+xsT', 'closet');
// script/closet.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
window.lockOfClosetInCP1 = false;
var res1 = 0;
var res2 = 0;
var res3 = 0;
var res4 = 0;
var res = "";
cc.Class({
  "extends": cc.Component,
  properties: {
    sprite_Frame1: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame2: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame3: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame4: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame5: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame6: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame7: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame8: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame9: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame0: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_FrameOpen: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  // LIFE-CYCLE CALLBACKS:
  closet1: function closet1() {
    var button1 = this.node.getComponent(cc.Button);

    switch (res1) {
      case 0:
        button1.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button1.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button1.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button1.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button1.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button1.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button1.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button1.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button1.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button1.normalSprite = this.sprite_Frame0;
        break;
    }

    res1++;

    if (res1 === 10) {
      res1 = 0;
    }
  },
  closet2: function closet2() {
    var button2 = this.node.getComponent(cc.Button);

    switch (res2) {
      case 0:
        button2.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button2.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button2.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button2.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button2.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button2.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button2.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button2.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button2.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button2.normalSprite = this.sprite_Frame0;
        break;
    }

    res2++;

    if (res2 === 10) {
      res2 = 0;
    }
  },
  closet3: function closet3() {
    var button3 = this.node.getComponent(cc.Button);

    switch (res3) {
      case 0:
        button3.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button3.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button3.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button3.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button3.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button3.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button3.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button3.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button3.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button3.normalSprite = this.sprite_Frame0;
        break;
    }

    res3++;

    if (res3 === 10) {
      res3 = 0;
    }
  },
  closet4: function closet4() {
    var button4 = this.node.getComponent(cc.Button);

    switch (res4) {
      case 0:
        button4.normalSprite = this.sprite_Frame1;
        break;

      case 1:
        button4.normalSprite = this.sprite_Frame2;
        break;

      case 2:
        button4.normalSprite = this.sprite_Frame3;
        break;

      case 3:
        button4.normalSprite = this.sprite_Frame4;
        break;

      case 4:
        button4.normalSprite = this.sprite_Frame5;
        break;

      case 5:
        button4.normalSprite = this.sprite_Frame6;
        break;

      case 6:
        button4.normalSprite = this.sprite_Frame7;
        break;

      case 7:
        button4.normalSprite = this.sprite_Frame8;
        break;

      case 8:
        button4.normalSprite = this.sprite_Frame9;
        break;

      case 9:
        button4.normalSprite = this.sprite_Frame0;
        break;
    }

    res4++;

    if (res4 === 10) {
      res4 = 0;
    }
  },
  closetJudge: function closetJudge() {
    res = '' + res1 + res2 + res3 + res4;
    cc.log(res);

    if (res === "0002") {
      var closet = this.node.parent.getComponent(cc.Sprite);
      cc.log(closet);
      cc.log(this.node.sprite_FrameOpen);
      closet.spriteFrame = this.sprite_FrameOpen;
      cc.log("success");
      window.lockOfClosetInCP1 = true;
    }
  },
  // onLoad () {
  //
  // },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxjbG9zZXQuanMiXSwibmFtZXMiOlsid2luZG93IiwibG9ja09mQ2xvc2V0SW5DUDEiLCJyZXMxIiwicmVzMiIsInJlczMiLCJyZXM0IiwicmVzIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzcHJpdGVfRnJhbWUxIiwidHlwZSIsIlNwcml0ZUZyYW1lIiwic3ByaXRlX0ZyYW1lMiIsInNwcml0ZV9GcmFtZTMiLCJzcHJpdGVfRnJhbWU0Iiwic3ByaXRlX0ZyYW1lNSIsInNwcml0ZV9GcmFtZTYiLCJzcHJpdGVfRnJhbWU3Iiwic3ByaXRlX0ZyYW1lOCIsInNwcml0ZV9GcmFtZTkiLCJzcHJpdGVfRnJhbWUwIiwic3ByaXRlX0ZyYW1lT3BlbiIsImNsb3NldDEiLCJidXR0b24xIiwibm9kZSIsImdldENvbXBvbmVudCIsIkJ1dHRvbiIsIm5vcm1hbFNwcml0ZSIsImNsb3NldDIiLCJidXR0b24yIiwiY2xvc2V0MyIsImJ1dHRvbjMiLCJjbG9zZXQ0IiwiYnV0dG9uNCIsImNsb3NldEp1ZGdlIiwibG9nIiwiY2xvc2V0IiwicGFyZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQUEsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixLQUEzQjtBQUNBLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQVY7QUFBYSxJQUFJQyxJQUFJLEdBQUUsQ0FBVjtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsR0FBRyxHQUFFLEVBQVQ7QUFDbERDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSQyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEMsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FEUDtJQUtSQyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEYsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FMUDtJQVNSRSxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FUUDtJQWFSRyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWEosSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FiUDtJQWdCTkksYUFBYSxFQUFFO01BQ2IsV0FBVSxJQURHO01BRWJMLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZJLENBaEJUO0lBb0JSSyxhQUFhLEVBQUU7TUFDWCxXQUFVLElBREM7TUFFWE4sSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkUsQ0FwQlA7SUF1Qk5NLGFBQWEsRUFBRTtNQUNiLFdBQVUsSUFERztNQUViUCxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007SUFGSSxDQXZCVDtJQTJCUk8sYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhSLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFLENBM0JQO0lBOEJOUSxhQUFhLEVBQUU7TUFDYixXQUFVLElBREc7TUFFYlQsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkksQ0E5QlQ7SUFrQ1JTLGFBQWEsRUFBRTtNQUNYLFdBQVUsSUFEQztNQUVYVixJQUFJLEVBQUVMLEVBQUUsQ0FBQ007SUFGRSxDQWxDUDtJQXNDUlUsZ0JBQWdCLEVBQUU7TUFDZCxXQUFVLElBREk7TUFFZFgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRks7RUF0Q1YsQ0FIUDtFQStDTDtFQUNBVyxPQWhESyxxQkFnREk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFFQSxRQUFRMUIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTdUIsT0FBTyxDQUFDSSxZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLZixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVFXLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLZCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFVLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVNTLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVFRLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLWCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFPLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLVixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFNLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFLLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbEQsS0FBSyxDQUFMO1FBQVFJLE9BQU8sQ0FBQ0ksWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ0RDs7SUFXQ3BCLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0FsRUk7RUFtRUw0QixPQW5FSyxxQkFtRUk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS0wsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFDQSxRQUFRekIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTNEIsT0FBTyxDQUFDRixZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNvQixPQUFPLENBQUNGLFlBQVIsR0FBdUIsS0FBS2YsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTaUIsT0FBTyxDQUFDRixZQUFSLEdBQXVCLEtBQUtkLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2dCLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNlLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLWCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNhLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLVixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNZLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNXLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNVLE9BQU8sQ0FBQ0YsWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ2RDs7SUFXQ25CLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0FwRkk7RUFxRkw2QixPQXJGSyxxQkFxRkk7SUFDTCxJQUFJQyxPQUFPLEdBQUUsS0FBS1AsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjs7SUFDQSxRQUFReEIsSUFBUjtNQUNJLEtBQUssQ0FBTDtRQUFTNkIsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtsQixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNzQixPQUFPLENBQUNKLFlBQVIsR0FBdUIsS0FBS2YsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTbUIsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtkLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2tCLE9BQU8sQ0FBQ0osWUFBUixHQUF1QixLQUFLYixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNpQixPQUFPLENBQUNKLFlBQVIsR0FBdUIsS0FBS1osYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTZ0IsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtYLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2UsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtWLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2MsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtULGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2EsT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtSLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU1ksT0FBTyxDQUFDSixZQUFSLEdBQXVCLEtBQUtQLGFBQTVCO1FBQTBDO0lBVnZEOztJQVdDbEIsSUFBSTs7SUFDTCxJQUFHQSxJQUFJLEtBQUcsRUFBVixFQUFhO01BQ1RBLElBQUksR0FBQyxDQUFMO0lBQ0g7RUFDSixDQXRHSTtFQXVHTDhCLE9BdkdLLHFCQXVHSTtJQUNMLElBQUlDLE9BQU8sR0FBRSxLQUFLVCxJQUFMLENBQVVDLFlBQVYsQ0FBdUJwQixFQUFFLENBQUNxQixNQUExQixDQUFiOztJQUNBLFFBQVF2QixJQUFSO01BQ0ksS0FBSyxDQUFMO1FBQVM4QixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS2xCLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU3dCLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLZixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNxQixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS2QsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTb0IsT0FBTyxDQUFDTixZQUFSLEdBQXVCLEtBQUtiLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU21CLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLWixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNrQixPQUFPLENBQUNOLFlBQVIsR0FBdUIsS0FBS1gsYUFBNUI7UUFBMEM7O01BQ25ELEtBQUssQ0FBTDtRQUFTaUIsT0FBTyxDQUFDTixZQUFSLEdBQXVCLEtBQUtWLGFBQTVCO1FBQTBDOztNQUNuRCxLQUFLLENBQUw7UUFBU2dCLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLVCxhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNlLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLUixhQUE1QjtRQUEwQzs7TUFDbkQsS0FBSyxDQUFMO1FBQVNjLE9BQU8sQ0FBQ04sWUFBUixHQUF1QixLQUFLUCxhQUE1QjtRQUEwQztJQVZ2RDs7SUFXQ2pCLElBQUk7O0lBQ0wsSUFBR0EsSUFBSSxLQUFHLEVBQVYsRUFBYTtNQUNUQSxJQUFJLEdBQUMsQ0FBTDtJQUNIO0VBQ0osQ0F4SEk7RUF5SEwrQixXQXpISyx5QkF5SFE7SUFDVDlCLEdBQUcsR0FBRSxLQUFHSixJQUFILEdBQVFDLElBQVIsR0FBYUMsSUFBYixHQUFrQkMsSUFBdkI7SUFDQUUsRUFBRSxDQUFDOEIsR0FBSCxDQUFPL0IsR0FBUDs7SUFDQSxJQUFHQSxHQUFHLEtBQUcsTUFBVCxFQUFnQjtNQUNaLElBQUlnQyxNQUFNLEdBQUUsS0FBS1osSUFBTCxDQUFVYSxNQUFWLENBQWlCWixZQUFqQixDQUE4QnBCLEVBQUUsQ0FBQ2lDLE1BQWpDLENBQVo7TUFDQWpDLEVBQUUsQ0FBQzhCLEdBQUgsQ0FBT0MsTUFBUDtNQUNBL0IsRUFBRSxDQUFDOEIsR0FBSCxDQUFPLEtBQUtYLElBQUwsQ0FBVUgsZ0JBQWpCO01BQ0FlLE1BQU0sQ0FBQ0csV0FBUCxHQUFxQixLQUFLbEIsZ0JBQTFCO01BQ0FoQixFQUFFLENBQUM4QixHQUFILENBQU8sU0FBUDtNQUNBckMsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixJQUEzQjtJQUNIO0VBQ0osQ0FwSUk7RUFxSUo7RUFDQTtFQUNBO0VBRUR5QyxLQXpJSyxtQkF5SUksQ0FFUixDQTNJSSxDQTZJTDs7QUE3SUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbndpbmRvdy5sb2NrT2ZDbG9zZXRJbkNQMSA9IGZhbHNlO1xubGV0IHJlczEgPTA7bGV0IHJlczIgPTA7IGxldCByZXMzID0wIDtsZXQgcmVzNCA9MDtsZXQgcmVzID1cIlwiO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc3ByaXRlX0ZyYW1lMSA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWUyIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH0sXG4gICAgICAgIHNwcml0ZV9GcmFtZTMgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lNCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTUgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lNiA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTcgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lOCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LHNwcml0ZV9GcmFtZTkgOntcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxuICAgICAgICAgICAgdHlwZSA6Y2MuU3ByaXRlRnJhbWVcbiAgICAgICAgfSxcbiAgICAgICAgc3ByaXRlX0ZyYW1lMCA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWVPcGVuIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG4gICAgY2xvc2V0MSgpe1xuICAgICAgICBsZXQgYnV0dG9uMSA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIHN3aXRjaCAocmVzMSkge1xuICAgICAgICAgICAgY2FzZSAwIDogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTE7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDEgOiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMjticmVhaztcbiAgICAgICAgICAgIGNhc2UgMjogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU0O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA0IDogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTU7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDU6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU2O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA2OiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNzogYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTg7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDg6IGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU5O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA5OiBidXR0b24xLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczEgKys7XG4gICAgICAgIGlmKHJlczE9PT0xMCl7XG4gICAgICAgICAgICByZXMxPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDIoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjIgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXMyKSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b24yLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczIgKys7XG4gICAgICAgIGlmKHJlczI9PT0xMCl7XG4gICAgICAgICAgICByZXMyPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDMoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjMgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXMzKSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjMubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczMgKys7XG4gICAgICAgIGlmKHJlczM9PT0xMCl7XG4gICAgICAgICAgICByZXMzPTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldDQoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjQgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgc3dpdGNoIChyZXM0KSB7XG4gICAgICAgICAgICBjYXNlIDAgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMTticmVhaztcbiAgICAgICAgICAgIGNhc2UgMSA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyO2JyZWFrO1xuICAgICAgICAgICAgY2FzZSAyIDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTM7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNDticmVhaztcbiAgICAgICAgICAgIGNhc2UgNCA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU1O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTY7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lNzticmVhaztcbiAgICAgICAgICAgIGNhc2UgNyA6IGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWU4O2JyZWFrO1xuICAgICAgICAgICAgY2FzZSA4IDogYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTk7YnJlYWs7XG4gICAgICAgICAgICBjYXNlIDkgOiBidXR0b240Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMDticmVhaztcbiAgICAgICAgfXJlczQgKys7XG4gICAgICAgIGlmKHJlczQ9PT0xMCl7XG4gICAgICAgICAgICByZXM0PTA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNsb3NldEp1ZGdlKCl7XG4gICAgICAgIHJlcyA9JycrcmVzMStyZXMyK3JlczMrcmVzNDtcbiAgICAgICAgY2MubG9nKHJlcyk7XG4gICAgICAgIGlmKHJlcz09PVwiMDAwMlwiKXtcbiAgICAgICAgICAgIGxldCBjbG9zZXQgPXRoaXMubm9kZS5wYXJlbnQuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgICAgICBjYy5sb2coY2xvc2V0KVxuICAgICAgICAgICAgY2MubG9nKHRoaXMubm9kZS5zcHJpdGVfRnJhbWVPcGVuKVxuICAgICAgICAgICAgY2xvc2V0LnNwcml0ZUZyYW1lID0gdGhpcy5zcHJpdGVfRnJhbWVPcGVuO1xuICAgICAgICAgICAgY2MubG9nKFwic3VjY2Vzc1wiKTtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NrT2ZDbG9zZXRJbkNQMSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICAvLyBvbkxvYWQgKCkge1xuICAgICAvL1xuICAgICAvLyB9LFxuXG4gICAgc3RhcnQgKCkge1xuXG4gICAgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/switch.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'efbe1Uv2OtAB5rrrirEZfoB', 'switch');
// script/switch.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

/*
电闸
 */
window.lockOfSwitchInCP1 = false;
var res1 = 1;
var res2 = 1;
var res3 = -1;
var res4 = 1;
var res5 = -1;
var res6 = 1;
var res7 = 1;
var res8 = -1;
cc.Class({
  "extends": cc.Component,
  properties: {
    sprite_Frame1: {
      "default": null,
      type: cc.SpriteFrame
    },
    sprite_Frame2: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  switch1: function switch1() {
    var button1 = this.node.getComponent(cc.Button);
    res1 = -res1;

    if (res1 === 1) {
      button1.normalSprite = this.sprite_Frame1;
    } else {
      button1.normalSprite = this.sprite_Frame2;
    }

    cc.log("res1" + res1);
  },
  switch2: function switch2() {
    var button2 = this.node.getComponent(cc.Button);
    res2 = -res2;

    if (res2 === 1) {
      button2.normalSprite = this.sprite_Frame1;
    } else {
      button2.normalSprite = this.sprite_Frame2;
    }

    cc.log("res2" + res2);
  },
  switch3: function switch3() {
    var button3 = this.node.getComponent(cc.Button);

    if (res3 === 1) {
      button3.normalSprite = this.sprite_Frame1;
    } else {
      button3.normalSprite = this.sprite_Frame2;
    }

    res3 = -res3;
    cc.log(res3);
  },
  switch4: function switch4() {
    var button4 = this.node.getComponent(cc.Button);

    if (res4 === 1) {
      button4.normalSprite = this.sprite_Frame1;
    } else {
      button4.normalSprite = this.sprite_Frame2;
    }

    res4 = -res4;
    cc.log(res4);
  },
  switch5: function switch5() {
    var button5 = this.node.getComponent(cc.Button);

    if (res5 === 1) {
      button5.normalSprite = this.sprite_Frame1;
    } else {
      button5.normalSprite = this.sprite_Frame2;
    }

    res5 = -res5;
    cc.log(res5);
  },
  switch6: function switch6() {
    var button6 = this.node.getComponent(cc.Button);

    if (res6 === 1) {
      button6.normalSprite = this.sprite_Frame1;
    } else {
      button6.normalSprite = this.sprite_Frame2;
    }

    res6 = -res6;
    cc.log(res6);
  },
  switch7: function switch7() {
    var button7 = this.node.getComponent(cc.Button);

    if (res7 === 1) {
      button7.normalSprite = this.sprite_Frame1;
    } else {
      button7.normalSprite = this.sprite_Frame2;
    }

    res7 = -res7;
    cc.log(res7);
  },
  switch8: function switch8() {
    var button8 = this.node.getComponent(cc.Button);

    if (res8 == 1) {
      button8.normalSprite = this.sprite_Frame1;
    } else {
      button8.normalSprite = this.sprite_Frame2;
    }

    res8 = -res8;
    cc.log(res8);
  },
  switch9: function switch9() {
    if (res1 + res3 + res2 + res4 + res5 + res6 + res7 + res8 == 8) {
      window.lockOfSwitchInCP1 = false;
      cc.log("success");
    }

    ;
    cc.log(res1 + res3 + res2 + res4 + res5 + res6 + res7 + res8);
  },
  onLoad: function onLoad() {// cc.resources.load('switch1')
    //  cc.resources.load('switch2')
    // this.sprites =  cc.resources.load("resources/2.png")
    //  console.log(this.sprites);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFxzd2l0Y2guanMiXSwibmFtZXMiOlsid2luZG93IiwibG9ja09mU3dpdGNoSW5DUDEiLCJyZXMxIiwicmVzMiIsInJlczMiLCJyZXM0IiwicmVzNSIsInJlczYiLCJyZXM3IiwicmVzOCIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3ByaXRlX0ZyYW1lMSIsInR5cGUiLCJTcHJpdGVGcmFtZSIsInNwcml0ZV9GcmFtZTIiLCJzd2l0Y2gxIiwiYnV0dG9uMSIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJCdXR0b24iLCJub3JtYWxTcHJpdGUiLCJsb2ciLCJzd2l0Y2gyIiwiYnV0dG9uMiIsInN3aXRjaDMiLCJidXR0b24zIiwic3dpdGNoNCIsImJ1dHRvbjQiLCJzd2l0Y2g1IiwiYnV0dG9uNSIsInN3aXRjaDYiLCJidXR0b242Iiwic3dpdGNoNyIsImJ1dHRvbjciLCJzd2l0Y2g4IiwiYnV0dG9uOCIsInN3aXRjaDkiLCJvbkxvYWQiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0FBLE1BQU0sQ0FBQ0MsaUJBQVAsR0FBMkIsS0FBM0I7QUFDQSxJQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUFhLElBQUlDLElBQUksR0FBRSxDQUFWO0FBQy9ELElBQUlDLElBQUksR0FBRSxDQUFWO0FBQVksSUFBSUMsSUFBSSxHQUFFLENBQUMsQ0FBWDtBQUNaQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUU7SUFFUkMsYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhDLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFLENBRlA7SUFNUkMsYUFBYSxFQUFFO01BQ1gsV0FBVSxJQURDO01BRVhGLElBQUksRUFBRUwsRUFBRSxDQUFDTTtJQUZFO0VBTlAsQ0FIUDtFQWVMRSxPQWZLLHFCQWVLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixDQUFiO0lBQ0FwQixJQUFJLEdBQUUsQ0FBQ0EsSUFBUDs7SUFDQSxJQUFHQSxJQUFJLEtBQUcsQ0FBVixFQUFZO01BQ1JpQixPQUFPLENBQUNJLFlBQVIsR0FBdUIsS0FBS1QsYUFBNUI7SUFDSCxDQUZELE1BRUs7TUFDREssT0FBTyxDQUFDSSxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBRURQLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPLFNBQU90QixJQUFkO0VBRUgsQ0ExQkk7RUEyQkx1QixPQTNCSyxxQkEyQks7SUFDTixJQUFJQyxPQUFPLEdBQUUsS0FBS04sSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7SUFDQW5CLElBQUksR0FBRSxDQUFDQSxJQUFQOztJQUNBLElBQUdBLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUnVCLE9BQU8sQ0FBQ0gsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEWSxPQUFPLENBQUNILFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFFRFAsRUFBRSxDQUFDYyxHQUFILENBQU8sU0FBT3JCLElBQWQ7RUFDSCxDQXJDSTtFQXNDTHdCLE9BdENLLHFCQXNDSztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLUixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHbEIsSUFBSSxLQUFHLENBQVYsRUFBWTtNQUNSd0IsT0FBTyxDQUFDTCxZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0RjLE9BQU8sQ0FBQ0wsWUFBUixHQUF1QixLQUFLTixhQUE1QjtJQUNIOztJQUNEYixJQUFJLEdBQUUsQ0FBQ0EsSUFBUDtJQUNBTSxFQUFFLENBQUNjLEdBQUgsQ0FBT3BCLElBQVA7RUFDSCxDQWhESTtFQWlETHlCLE9BakRLLHFCQWlESztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLVixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHakIsSUFBSSxLQUFHLENBQVYsRUFBWTtNQUNSeUIsT0FBTyxDQUFDUCxZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0RnQixPQUFPLENBQUNQLFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFDRFosSUFBSSxHQUFFLENBQUNBLElBQVA7SUFDQUssRUFBRSxDQUFDYyxHQUFILENBQU9uQixJQUFQO0VBQ0gsQ0EzREk7RUE0REwwQixPQTVESyxxQkE0REs7SUFDTixJQUFJQyxPQUFPLEdBQUUsS0FBS1osSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7O0lBRUEsSUFBR2hCLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUjBCLE9BQU8sQ0FBQ1QsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEa0IsT0FBTyxDQUFDVCxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBQ0RYLElBQUksR0FBRSxDQUFDQSxJQUFQO0lBQ0FJLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPbEIsSUFBUDtFQUNILENBdEVJO0VBdUVMMkIsT0F2RUsscUJBdUVLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtkLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixDQUFiOztJQUVBLElBQUdmLElBQUksS0FBRyxDQUFWLEVBQVk7TUFDUjJCLE9BQU8sQ0FBQ1gsWUFBUixHQUF1QixLQUFLVCxhQUE1QjtJQUNILENBRkQsTUFFSztNQUNEb0IsT0FBTyxDQUFDWCxZQUFSLEdBQXVCLEtBQUtOLGFBQTVCO0lBQ0g7O0lBQ0RWLElBQUksR0FBRSxDQUFDQSxJQUFQO0lBQ0FHLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPakIsSUFBUDtFQUNILENBakZJO0VBa0ZMNEIsT0FsRksscUJBa0ZLO0lBQ04sSUFBSUMsT0FBTyxHQUFFLEtBQUtoQixJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBYjs7SUFFQSxJQUFHZCxJQUFJLEtBQUcsQ0FBVixFQUFZO01BQ1I0QixPQUFPLENBQUNiLFlBQVIsR0FBdUIsS0FBS1QsYUFBNUI7SUFDSCxDQUZELE1BRUs7TUFDRHNCLE9BQU8sQ0FBQ2IsWUFBUixHQUF1QixLQUFLTixhQUE1QjtJQUNIOztJQUNEVCxJQUFJLEdBQUUsQ0FBQ0EsSUFBUDtJQUNBRSxFQUFFLENBQUNjLEdBQUgsQ0FBT2hCLElBQVA7RUFDSCxDQTVGSTtFQTZGTDZCLE9BN0ZLLHFCQTZGSztJQUNOLElBQUlDLE9BQU8sR0FBRSxLQUFLbEIsSUFBTCxDQUFVQyxZQUFWLENBQXVCWCxFQUFFLENBQUNZLE1BQTFCLENBQWI7O0lBRUEsSUFBR2IsSUFBSSxJQUFFLENBQVQsRUFBVztNQUNQNkIsT0FBTyxDQUFDZixZQUFSLEdBQXVCLEtBQUtULGFBQTVCO0lBQ0gsQ0FGRCxNQUVLO01BQ0R3QixPQUFPLENBQUNmLFlBQVIsR0FBdUIsS0FBS04sYUFBNUI7SUFDSDs7SUFDRFIsSUFBSSxHQUFFLENBQUNBLElBQVA7SUFDQUMsRUFBRSxDQUFDYyxHQUFILENBQU9mLElBQVA7RUFDSCxDQXZHSTtFQXdHTDhCLE9BeEdLLHFCQXdHSztJQUVOLElBQUlyQyxJQUFJLEdBQUNFLElBQUwsR0FBVUQsSUFBVixHQUFlRSxJQUFmLEdBQW9CQyxJQUFwQixHQUF5QkMsSUFBekIsR0FBOEJDLElBQTlCLEdBQW1DQyxJQUFwQyxJQUEyQyxDQUE5QyxFQUFnRDtNQUM1Q1QsTUFBTSxDQUFDQyxpQkFBUCxHQUEyQixLQUEzQjtNQUNBUyxFQUFFLENBQUNjLEdBQUgsQ0FBTyxTQUFQO0lBQ0g7O0lBQUE7SUFDRGQsRUFBRSxDQUFDYyxHQUFILENBQU90QixJQUFJLEdBQUNFLElBQUwsR0FBVUQsSUFBVixHQUFlRSxJQUFmLEdBQW9CQyxJQUFwQixHQUF5QkMsSUFBekIsR0FBOEJDLElBQTlCLEdBQW1DQyxJQUExQztFQUVILENBaEhJO0VBa0hKK0IsTUFsSEksb0JBa0hNLENBQ047SUFDQTtJQUNEO0lBQ0E7RUFDRixDQXZIRztFQXlITEMsS0F6SEssbUJBeUhJLENBRVIsQ0EzSEksQ0E2SEw7O0FBN0hLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxuLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbi8qXG7nlLXpl7hcbiAqL1xud2luZG93LmxvY2tPZlN3aXRjaEluQ1AxID0gZmFsc2U7XG5sZXQgcmVzMSA9IDE7bGV0IHJlczIgPTE7bGV0IHJlczMgPS0xO2xldCByZXM0ID0xO2xldCByZXM1ID0tMTtsZXQgcmVzNiA9MTtcbmxldCByZXM3ID0xO2xldCByZXM4ID0tMTtcbmNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG5cbiAgICAgICAgc3ByaXRlX0ZyYW1lMSA6e1xuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXG4gICAgICAgICAgICB0eXBlIDpjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzcHJpdGVfRnJhbWUyIDp7XG4gICAgICAgICAgICBkZWZhdWx0IDogbnVsbCxcbiAgICAgICAgICAgIHR5cGUgOmNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgc3dpdGNoMSAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjEgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgcmVzMSA9LXJlczE7XG4gICAgICAgIGlmKHJlczE9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjEubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uMS5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInJlczFcIityZXMxKTtcblxuICAgIH0sXG4gICAgc3dpdGNoMiAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjIgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgcmVzMiA9LXJlczI7XG4gICAgICAgIGlmKHJlczI9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjIubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uMi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInJlczJcIityZXMyKTtcbiAgICB9LFxuICAgIHN3aXRjaDMgKCl7XG4gICAgICAgIGxldCBidXR0b24zID10aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG5cbiAgICAgICAgaWYocmVzMz09PTEpe1xuICAgICAgICAgICAgYnV0dG9uMy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTFcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBidXR0b24zLm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMlxuICAgICAgICB9XG4gICAgICAgIHJlczMgPS1yZXMzO1xuICAgICAgICBjYy5sb2cocmVzMyk7XG4gICAgfSxcbiAgICBzd2l0Y2g0ICgpe1xuICAgICAgICBsZXQgYnV0dG9uNCA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIGlmKHJlczQ9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjQubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uNC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM0ID0tcmVzNDtcbiAgICAgICAgY2MubG9nKHJlczQpO1xuICAgIH0sXG4gICAgc3dpdGNoNSAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjUgPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcblxuICAgICAgICBpZihyZXM1PT09MSl7XG4gICAgICAgICAgICBidXR0b241Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMVxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIGJ1dHRvbjUubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUyXG4gICAgICAgIH1cbiAgICAgICAgcmVzNSA9LXJlczU7XG4gICAgICAgIGNjLmxvZyhyZXM1KTtcbiAgICB9LFxuICAgIHN3aXRjaDYgKCl7XG4gICAgICAgIGxldCBidXR0b242ID10aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG5cbiAgICAgICAgaWYocmVzNj09PTEpe1xuICAgICAgICAgICAgYnV0dG9uNi5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTFcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBidXR0b242Lm5vcm1hbFNwcml0ZSA9IHRoaXMuc3ByaXRlX0ZyYW1lMlxuICAgICAgICB9XG4gICAgICAgIHJlczYgPS1yZXM2O1xuICAgICAgICBjYy5sb2cocmVzNik7XG4gICAgfSxcbiAgICBzd2l0Y2g3ICgpe1xuICAgICAgICBsZXQgYnV0dG9uNyA9dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuXG4gICAgICAgIGlmKHJlczc9PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjcubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uNy5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM3ID0tcmVzNztcbiAgICAgICAgY2MubG9nKHJlczcpO1xuICAgIH0sXG4gICAgc3dpdGNoOCAoKXtcbiAgICAgICAgbGV0IGJ1dHRvbjggPXRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcblxuICAgICAgICBpZihyZXM4PT0xKXtcbiAgICAgICAgICAgIGJ1dHRvbjgubm9ybWFsU3ByaXRlID0gdGhpcy5zcHJpdGVfRnJhbWUxXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgYnV0dG9uOC5ub3JtYWxTcHJpdGUgPSB0aGlzLnNwcml0ZV9GcmFtZTJcbiAgICAgICAgfVxuICAgICAgICByZXM4ID0tcmVzODtcbiAgICAgICAgY2MubG9nKHJlczgpO1xuICAgIH0sXG4gICAgc3dpdGNoOSAoKXtcblxuICAgICAgICBpZigocmVzMStyZXMzK3JlczIrcmVzNCtyZXM1K3JlczYrcmVzNytyZXM4KT09OCl7XG4gICAgICAgICAgICB3aW5kb3cubG9ja09mU3dpdGNoSW5DUDEgPSBmYWxzZTtcbiAgICAgICAgICAgIGNjLmxvZyhcInN1Y2Nlc3NcIik7XG4gICAgICAgIH07XG4gICAgICAgIGNjLmxvZyhyZXMxK3JlczMrcmVzMityZXM0K3JlczUrcmVzNityZXM3K3JlczgpXG5cbiAgICB9LFxuXG4gICAgIG9uTG9hZCAoKSB7XG4gICAgICAgICAvLyBjYy5yZXNvdXJjZXMubG9hZCgnc3dpdGNoMScpXG4gICAgICAgICAvLyAgY2MucmVzb3VyY2VzLmxvYWQoJ3N3aXRjaDInKVxuICAgICAgICAvLyB0aGlzLnNwcml0ZXMgPSAgY2MucmVzb3VyY2VzLmxvYWQoXCJyZXNvdXJjZXMvMi5wbmdcIilcbiAgICAgICAgLy8gIGNvbnNvbGUubG9nKHRoaXMuc3ByaXRlcyk7XG4gICAgIH0sXG5cbiAgICBzdGFydCAoKSB7XG5cbiAgICB9LFxuXG4gICAgLy8gdXBkYXRlIChkdCkge30sXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------
