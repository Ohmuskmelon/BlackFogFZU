
require('./assets/script/closet');
require('./assets/script/gate');
require('./assets/script/stairlock');
require('./assets/script/switch');
